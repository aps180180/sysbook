
//import { BookGrid } from '../components/BookGrid.jsx'
import BookGrid from '../components/BookGrid.jsx';

const HomePage = () => {
  return (
    <BookGrid /> 
  )
}
export default HomePage; 